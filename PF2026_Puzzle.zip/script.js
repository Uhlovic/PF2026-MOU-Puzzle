// Získání elementů
const puzzlePieces = document.querySelectorAll('.puzzle-piece');
const puzzleSlots = document.querySelectorAll('.puzzle-slot');
const completionOverlay = document.getElementById('completionOverlay');
const puzzlePiecesContainer = document.getElementById('puzzlePieces');

// Stav hry
let placedPieces = 0;
const totalPieces = 12;

// Zamíchání dílků při načtení
window.addEventListener('DOMContentLoaded', () => {
    shufflePieces();
    initializeVisiblePieces();
});

// Inicializace - zobrazit pouze prvních 3 dílky
function initializeVisiblePieces() {
    const piecesArray = Array.from(puzzlePieces);

    // Vytvořit pole indexů dílků k zobrazení (vybereme 3 náhodné)
    const allIndices = Array.from({length: 12}, (_, i) => i);
    const visibleIndices = [];

    // Náhodně vybrat 3 indexy
    for (let i = 0; i < 3; i++) {
        const randomIndex = Math.floor(Math.random() * allIndices.length);
        visibleIndices.push(allIndices[randomIndex]);
        allIndices.splice(randomIndex, 1);
    }

    // Skrýt všechny kromě vybraných 3
    piecesArray.forEach((piece, index) => {
        if (!visibleIndices.includes(index)) {
            piece.classList.add('hidden');
        }
    });
}

// Zobrazit další dílek z fronty
function showNextPiece() {
    const hiddenPieces = puzzlePiecesContainer.querySelectorAll('.puzzle-piece.hidden');
    if (hiddenPieces.length > 0) {
        const nextPiece = hiddenPieces[0];
        nextPiece.classList.remove('hidden');
        nextPiece.classList.add('newly-visible');

        // Odstranit animační třídu po dokončení animace
        setTimeout(() => {
            nextPiece.classList.remove('newly-visible');
        }, 400);
    }
}

// Funkce pro zamíchání dílků
function shufflePieces() {
    const piecesArray = Array.from(puzzlePieces);
    // Fisher-Yates shuffle algoritmus
    for (let i = piecesArray.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        puzzlePiecesContainer.appendChild(piecesArray[j]);
    }
}

// Drag and Drop události pro dílky
puzzlePieces.forEach(piece => {
    piece.addEventListener('dragstart', handleDragStart);
    piece.addEventListener('dragend', handleDragEnd);
});

// Drag and Drop události pro sloty
puzzleSlots.forEach(slot => {
    slot.addEventListener('dragover', handleDragOver);
    slot.addEventListener('dragleave', handleDragLeave);
    slot.addEventListener('drop', handleDrop);
});

let draggedPiece = null;

function handleDragStart(e) {
    // Zabránit přetažení správně umístěných dílků
    if (this.classList.contains('correct')) {
        e.preventDefault();
        return false;
    }

    draggedPiece = this;
    this.classList.add('dragging');
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/html', this.innerHTML);
}

function handleDragEnd(e) {
    this.classList.remove('dragging');
}

function handleDragOver(e) {
    if (e.preventDefault) {
        e.preventDefault();
    }

    // Povolit drop pouze pokud je slot prázdný
    if (!this.hasChildNodes() || this.children.length === 0) {
        e.dataTransfer.dropEffect = 'move';
        this.classList.add('drag-over');
    }

    return false;
}

function handleDragLeave(e) {
    this.classList.remove('drag-over');
}

function handleDrop(e) {
    if (e.stopPropagation) {
        e.stopPropagation();
    }

    this.classList.remove('drag-over');

    // Zkontrolovat, zda je slot prázdný nebo obsahuje špatně umístěný dílek
    if (this.hasChildNodes() && this.children.length > 0) {
        const existingPiece = this.children[0];
        // Pokud je tam správně umístěný dílek, nepřepisovat
        if (existingPiece.classList.contains('correct')) {
            return false;
        }
        // Pokud je tam špatně umístěný dílek, vrátit ho zpět
        if (existingPiece.classList.contains('incorrect')) {
            puzzlePiecesContainer.appendChild(existingPiece);
            existingPiece.classList.remove('placed', 'incorrect');
            existingPiece.setAttribute('draggable', 'true');
            this.classList.remove('filled');
        }
    }

    // Přidat dílek do slotu
    const slotPosition = parseInt(this.dataset.position);
    const pieceCorrectPosition = parseInt(draggedPiece.dataset.correctPosition);

    // Pokud dílek přichází z jiného slotu, vyčistit původní slot
    const previousSlot = draggedPiece.parentElement;
    if (previousSlot && previousSlot.classList.contains('puzzle-slot')) {
        previousSlot.classList.remove('filled');
    }

    // Přesunout dílek do slotu
    this.appendChild(draggedPiece);
    draggedPiece.classList.add('placed');
    draggedPiece.classList.remove('correct', 'incorrect');
    this.classList.add('filled');

    // Zkontrolovat, zda je dílek na správné pozici
    if (slotPosition === pieceCorrectPosition) {
        // Správná pozice - zelený signál
        draggedPiece.classList.add('correct');
        draggedPiece.setAttribute('draggable', 'false');
        placedPieces++;

        // Zobrazit další dílek z fronty
        showNextPiece();
    } else {
        // Špatná pozice - červený signál, lze přemístit
        draggedPiece.classList.add('incorrect');
        draggedPiece.setAttribute('draggable', 'true');
    }

    // Zkontrolovat, zda jsou všechny dílky umístěny správně
    checkCompletion();

    return false;
}

function checkCompletion() {
    // Zkontrolovat, zda jsou VŠECHNY dílky správně umístěné
    if (placedPieces === totalPieces) {
        // Puzzle je kompletní a správně složené!
        // Skrýt viditelné dílky (ale nechat kontejner)
        const visiblePieces = puzzlePiecesContainer.querySelectorAll('.puzzle-piece:not(.hidden)');
        visiblePieces.forEach(piece => {
            piece.style.opacity = '0';
            piece.style.pointerEvents = 'none';
        });

        // Spojit obrázek - odstranit mezery a rámečky
        setTimeout(() => {
            const puzzleGrid = document.getElementById('puzzleGrid');
            puzzleGrid.classList.add('completed');
        }, 500);

        // Zobrazit gratulaci (po dokončení animace spojení + 1 sekunda navíc)
        setTimeout(() => {
            showCompletionMessage();
        }, 3000);
    }
}

function showCompletionMessage() {
    completionOverlay.classList.add('show');

    // Přidání zvukového efektu (volitelné)
    playCompletionSound();
}

function playCompletionSound() {
    // Jednoduchý beep pomocí Web Audio API
    try {
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();

        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);

        oscillator.frequency.value = 800;
        oscillator.type = 'sine';

        gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);

        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 0.5);
    } catch (error) {
        // Pokud Web Audio API není podporováno, prostě přeskočíme
        console.log('Audio not supported');
    }
}

// Možnost zavřít overlay kliknutím
completionOverlay.addEventListener('click', () => {
    completionOverlay.classList.remove('show');
});

// Připojení reset tlačítka
const resetBtn = document.getElementById('resetBtn');
resetBtn.addEventListener('click', resetGame);

// Přepínání pozadí podle času (19:00-5:00 noc, jinak den)
function setBackgroundByTime() {
    const hour = new Date().getHours();
    const isNight = hour >= 19 || hour < 5;

    if (isNight) {
        document.body.style.backgroundImage = "url('BG_night.png')";
        document.body.classList.add('night-mode');
    } else {
        document.body.style.backgroundImage = "url('BG_day.png')";
        document.body.classList.remove('night-mode');
    }
}


// Nastavit pozadí při načtení stránky
setBackgroundByTime();

// Kontrolovat každou minutu, zda se změnil čas
setInterval(setBackgroundByTime, 60000);

// Resetování hry
function resetGame() {
    placedPieces = 0;

    // Vrátit mřížku do původního stavu
    const puzzleGrid = document.getElementById('puzzleGrid');
    puzzleGrid.classList.remove('completed');

    // Vrátit všechny dílky zpět
    puzzleSlots.forEach(slot => {
        if (slot.hasChildNodes()) {
            const piece = slot.firstChild;
            puzzlePiecesContainer.appendChild(piece);
            piece.setAttribute('draggable', 'true');
            piece.classList.remove('placed', 'correct', 'incorrect', 'newly-visible');
            piece.style.opacity = '';
            piece.style.pointerEvents = '';
            slot.classList.remove('filled');
        }
    });

    // Resetovat všechny dílky v kontejneru
    puzzlePiecesContainer.querySelectorAll('.puzzle-piece').forEach(piece => {
        piece.style.opacity = '';
        piece.style.pointerEvents = '';
    });

    // Zamíchat znovu
    shufflePieces();

    // Resetovat viditelnost - zobrazit jen prvních 3
    initializeVisiblePieces();

    // Skrýt overlay
    completionOverlay.classList.remove('show');
}
